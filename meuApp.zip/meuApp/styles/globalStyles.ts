import { StyleSheet } from 'react-native';

// Cores principais do SPARK
export const SparkColors = {
  primary: '#B8DBD9',
  white: '#FFFFFF',
  lightGray: '#F1F1F1',
  black: '#000000',
  darkBackground: '#1A1A1A',
  darkCard: '#2D2D2D',
  danger: '#FF6B6B',
  warning: '#FFA500',
};

// Estilos globais reutilizáveis
export const GlobalStyles = StyleSheet.create({
  // Botões
  primaryButton: {
    backgroundColor: SparkColors.primary,
    paddingHorizontal: 40,
    paddingVertical: 15,
    borderRadius: 200,
    alignItems: 'center',
    justifyContent: 'center',
  },
  primaryButtonText: {
    color: SparkColors.black,
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  secondaryButton: {
    backgroundColor: 'transparent',
    borderWidth: 2,
    borderColor: SparkColors.primary,
    paddingHorizontal: 40,
    paddingVertical: 15,
    borderRadius: 200,
    alignItems: 'center',
    justifyContent: 'center',
  },
  secondaryButtonText: {
    color: SparkColors.primary,
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  
  // Cartões
  card: {
    padding: 20,
    borderRadius: 30,
    marginBottom: 15,
  },
  cardLight: {
    backgroundColor: SparkColors.lightGray,
  },
  cardDark: {
    backgroundColor: SparkColors.darkCard,
  },
  
  // Textos
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: SparkColors.primary,
  },
  subtitle: {
    fontSize: 20,
    fontWeight: '700',
    color: SparkColors.primary,
    marginBottom: 15,
  },
  body: {
    fontSize: 16,
    lineHeight: 24,
  },
  caption: {
    fontSize: 14,
    opacity: 0.7,
  },
  
  // Layout
  container: {
    flex: 1,
    paddingHorizontal: 20,
  },
  section: {
    marginVertical: 20,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  center: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  
  // Sombras (usando boxShadow para web)
  shadow: {
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
});

// Função helper para obter estilos baseados no tema
export const getThemedStyles = (colorScheme: 'light' | 'dark') => ({
  backgroundColor: colorScheme === 'dark' ? SparkColors.darkBackground : SparkColors.white,
  textColor: colorScheme === 'dark' ? SparkColors.white : SparkColors.black,
  cardColor: colorScheme === 'dark' ? SparkColors.darkCard : SparkColors.lightGray,
  borderColor: colorScheme === 'dark' ? SparkColors.darkCard : SparkColors.lightGray,
});