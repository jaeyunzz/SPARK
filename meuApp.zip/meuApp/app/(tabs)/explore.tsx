import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert
} from 'react-native';
import { ThemedView } from '@/components/ThemedView';
import { ThemedText } from '@/components/ThemedText';
import { useColorScheme } from '@/hooks/useColorScheme';

export default function SettingsScreen() {
  const colorScheme = useColorScheme();
  const [settings, setSettings] = useState({
    notifications: true,
    realTimeData: true,
    darkMode: colorScheme === 'dark',
    autoConnect: false,
    showVoltage: true,
    showCurrent: true,
    showConsumption: true,
    showCost: true,
    alertsEnabled: true,
    highConsumption: 80,
  });

  const styles = getStyles(colorScheme ?? 'light');

  const toggleSetting = (key: string) => {
    setSettings(prev => ({
      ...prev,
      [key]: !prev[key as keyof typeof prev]
    }));
  };

  const exportData = () => {
    Alert.alert(
      'Exportar Dados',
      'Dados de consumo exportados com sucesso!',
      [{ text: 'OK' }]
    );
  };

  const resetApp = () => {
    Alert.alert(
      'Resetar Aplicativo',
      'Tem certeza que deseja resetar todas as configurações?',
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Resetar', style: 'destructive', onPress: () => {
          // Reset logic here
          Alert.alert('Sucesso', 'Configurações resetadas!');
        }}
      ]
    );
  };

  return (
    <ThemedView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Configurações</Text>
        <Text style={styles.subtitle}>SPARK</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Seção de Exibição */}
        <View style={styles.section}>
          <ThemedText style={styles.sectionTitle}>Exibição de Dados</ThemedText>

          <View style={styles.settingItem}>
            <ThemedText style={styles.settingLabel}>Mostrar Tensão</ThemedText>
            <Switch
              value={settings.showVoltage}
              onValueChange={() => toggleSetting('showVoltage')}
              trackColor={{ false: '#767577', true: '#B8DBD9' }}
              thumbColor={settings.showVoltage ? '#FFFFFF' : '#F4F3F4'}
            />
          </View>

          <View style={styles.settingItem}>
            <ThemedText style={styles.settingLabel}>Mostrar Corrente</ThemedText>
            <Switch
              value={settings.showCurrent}
              onValueChange={() => toggleSetting('showCurrent')}
              trackColor={{ false: '#767577', true: '#B8DBD9' }}
              thumbColor={settings.showCurrent ? '#FFFFFF' : '#F4F3F4'}
            />
          </View>

          <View style={styles.settingItem}>
            <ThemedText style={styles.settingLabel}>Mostrar Consumo</ThemedText>
            <Switch
              value={settings.showConsumption}
              onValueChange={() => toggleSetting('showConsumption')}
              trackColor={{ false: '#767577', true: '#B8DBD9' }}
              thumbColor={settings.showConsumption ? '#FFFFFF' : '#F4F3F4'}
            />
          </View>

          <View style={styles.settingItem}>
            <ThemedText style={styles.settingLabel}>Mostrar Custos</ThemedText>
            <Switch
              value={settings.showCost}
              onValueChange={() => toggleSetting('showCost')}
              trackColor={{ false: '#767577', true: '#B8DBD9' }}
              thumbColor={settings.showCost ? '#FFFFFF' : '#F4F3F4'}
            />
          </View>
        </View>

        {/* Seção de Conectividade */}
        <View style={styles.section}>
          <ThemedText style={styles.sectionTitle}>Conectividade</ThemedText>

          <View style={styles.settingItem}>
            <ThemedText style={styles.settingLabel}>Dados em Tempo Real</ThemedText>
            <Switch
              value={settings.realTimeData}
              onValueChange={() => toggleSetting('realTimeData')}
              trackColor={{ false: '#767577', true: '#B8DBD9' }}
              thumbColor={settings.realTimeData ? '#FFFFFF' : '#F4F3F4'}
            />
          </View>

          <View style={styles.settingItem}>
            <ThemedText style={styles.settingLabel}>Conexão Automática</ThemedText>
            <Switch
              value={settings.autoConnect}
              onValueChange={() => toggleSetting('autoConnect')}
              trackColor={{ false: '#767577', true: '#B8DBD9' }}
              thumbColor={settings.autoConnect ? '#FFFFFF' : '#F4F3F4'}
            />
          </View>
        </View>

        {/* Seção de Notificações */}
        <View style={styles.section}>
          <ThemedText style={styles.sectionTitle}>Alertas e Notificações</ThemedText>

          <View style={styles.settingItem}>
            <ThemedText style={styles.settingLabel}>Notificações</ThemedText>
            <Switch
              value={settings.notifications}
              onValueChange={() => toggleSetting('notifications')}
              trackColor={{ false: '#767577', true: '#B8DBD9' }}
              thumbColor={settings.notifications ? '#FFFFFF' : '#F4F3F4'}
            />
          </View>

          <View style={styles.settingItem}>
            <ThemedText style={styles.settingLabel}>Alertas de Alto Consumo</ThemedText>
            <Switch
              value={settings.alertsEnabled}
              onValueChange={() => toggleSetting('alertsEnabled')}
              trackColor={{ false: '#767577', true: '#B8DBD9' }}
              thumbColor={settings.alertsEnabled ? '#FFFFFF' : '#F4F3F4'}
            />
          </View>
        </View>

        {/* Seção de Aparência */}
        <View style={styles.section}>
          <ThemedText style={styles.sectionTitle}>Aparência</ThemedText>

          <View style={styles.settingItem}>
            <ThemedText style={styles.settingLabel}>Modo Escuro</ThemedText>
            <Switch
              value={settings.darkMode}
              onValueChange={() => toggleSetting('darkMode')}
              trackColor={{ false: '#767577', true: '#B8DBD9' }}
              thumbColor={settings.darkMode ? '#FFFFFF' : '#F4F3F4'}
            />
          </View>
        </View>

        {/* Botões de Ação */}
        <View style={styles.actionSection}>
          <TouchableOpacity style={styles.primaryButton} onPress={exportData}>
            <Text style={styles.primaryButtonText}>📊 Exportar Dados</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.secondaryButton}>
            <Text style={styles.secondaryButtonText}>📖 Manual do Usuário</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.dangerButton} onPress={resetApp}>
            <Text style={styles.dangerButtonText}>🔄 Resetar Aplicativo</Text>
          </TouchableOpacity>
        </View>

        {/* Informações da Versão */}
        <View style={styles.versionInfo}>
          <ThemedText style={styles.versionText}>SPARK v1.0.0</ThemedText>
          <ThemedText style={styles.versionSubtext}>Sistema de Monitoramento de Energia</ThemedText>
        </View>
      </ScrollView>
    </ThemedView>
  );
}

const getStyles = (colorScheme: 'light' | 'dark') => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colorScheme === 'dark' ? '#1A1A1A' : '#FFFFFF',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 50,
    paddingBottom: 20,
    backgroundColor: colorScheme === 'dark' ? '#2D2D2D' : '#F1F1F1',
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#B8DBD9',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 16,
    color: colorScheme === 'dark' ? '#FFFFFF' : '#000000',
    opacity: 0.7,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  section: {
    marginVertical: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#B8DBD9',
    marginBottom: 15,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 15,
    paddingHorizontal: 20,
    backgroundColor: colorScheme === 'dark' ? '#2D2D2D' : '#F1F1F1',
    borderRadius: 30,
    marginBottom: 10,
  },
  settingLabel: {
    fontSize: 16,
    flex: 1,
  },
  actionSection: {
    marginVertical: 30,
  },
  primaryButton: {
    backgroundColor: '#B8DBD9',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 200,
    marginBottom: 15,
  },
  primaryButtonText: {
    color: '#000000',
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  secondaryButton: {
    backgroundColor: 'transparent',
    borderWidth: 2,
    borderColor: '#B8DBD9',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 200,
    marginBottom: 15,
  },
  secondaryButtonText: {
    color: '#B8DBD9',
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  dangerButton: {
    backgroundColor: '#FF6B6B',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 200,
    marginBottom: 15,
  },
  dangerButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  versionInfo: {
    alignItems: 'center',
    paddingVertical: 30,
    borderTopWidth: 1,
    borderTopColor: colorScheme === 'dark' ? '#2D2D2D' : '#F1F1F1',
  },
  versionText: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 5,
  },
  versionSubtext: {
    fontSize: 14,
    opacity: 0.7,
  },
});
