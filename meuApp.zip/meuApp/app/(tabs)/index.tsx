import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  Alert,
  Dimensions 
} from 'react-native';
import { ThemedView } from '@/components/ThemedView';
import { ThemedText } from '@/components/ThemedText';
import { useColorScheme } from '@/hooks/useColorScheme';

const { width } = Dimensions.get('window');

export default function HomeScreen() {
  const colorScheme = useColorScheme();
  const [isConnected, setIsConnected] = useState(false);
  const [sensorData, setSensorData] = useState({
    voltage: 0,
    current: 0,
    consumption: 0,
    device: '',
    usageTime: 0,
    costPerHour: 0.25,
    totalCost: 0
  });

  const styles = getStyles(colorScheme ?? 'light');

  // Simulação de dados em tempo real
  useEffect(() => {
    if (isConnected) {
      const interval = setInterval(() => {
        setSensorData(prev => ({
          ...prev,
          voltage: 120 + Math.random() * 10 - 5,
          current: 1.5 + Math.random() * 0.5 - 0.25,
          consumption: prev.consumption + 0.1,
          device: 'Ar Condicionado',
          usageTime: prev.usageTime + 1,
          totalCost: prev.totalCost + (0.25 / 3600)
        }));
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [isConnected]);

  const connectDevice = () => {
    Alert.alert(
      'Conectar Dispositivo',
      'Procurando por sensores SPARK...',
      [
        { text: 'Cancelar', style: 'cancel' },
        { 
          text: 'Conectar', 
          onPress: () => {
            setIsConnected(true);
            setSensorData(prev => ({ ...prev, usageTime: 0, totalCost: 0 }));
          }
        }
      ]
    );
  };

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <ThemedView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.logo}>SPARK</Text>
        <TouchableOpacity style={styles.menuButton}>
          <Text style={styles.menuIcon}>☰</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {!isConnected ? (
          // Estado desconectado
          <View style={styles.disconnectedContainer}>
            <Text style={styles.warningIcon}>⚠️</Text>
            <ThemedText style={styles.warningText}>
              Conecte o sensor em um dispositivo para mostrar dados
            </ThemedText>
            
            <TouchableOpacity style={styles.primaryButton} onPress={connectDevice}>
              <Text style={styles.primaryButtonText}>Conectar Dispositivo</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.secondaryButton}>
              <Text style={styles.secondaryButtonText}>Manual do Usuário</Text>
            </TouchableOpacity>
          </View>
        ) : (
          // Estado conectado
          <View style={styles.connectedContainer}>
            {/* Painel de Informações */}
            <View style={styles.infoPanel}>
              <ThemedText style={styles.sectionTitle}>Dados em Tempo Real</ThemedText>
              
              <View style={styles.infoGrid}>
                <View style={styles.infoCard}>
                  <ThemedText style={styles.infoLabel}>Tensão Elétrica</ThemedText>
                  <ThemedText style={styles.infoValue}>{sensorData.voltage.toFixed(1)}V</ThemedText>
                </View>
                
                <View style={styles.infoCard}>
                  <ThemedText style={styles.infoLabel}>Corrente</ThemedText>
                  <ThemedText style={styles.infoValue}>{sensorData.current.toFixed(2)}A</ThemedText>
                </View>
                
                <View style={styles.infoCard}>
                  <ThemedText style={styles.infoLabel}>Consumo</ThemedText>
                  <ThemedText style={styles.infoValue}>{sensorData.consumption.toFixed(1)}kWh</ThemedText>
                </View>
                
                <View style={styles.infoCard}>
                  <ThemedText style={styles.infoLabel}>Dispositivo</ThemedText>
                  <ThemedText style={styles.infoValue}>{sensorData.device}</ThemedText>
                </View>
                
                <View style={styles.infoCard}>
                  <ThemedText style={styles.infoLabel}>Tempo de Uso</ThemedText>
                  <ThemedText style={styles.infoValue}>{formatTime(sensorData.usageTime)}</ThemedText>
                </View>
                
                <View style={styles.infoCard}>
                  <ThemedText style={styles.infoLabel}>Custo/Hora</ThemedText>
                  <ThemedText style={styles.infoValue}>R${sensorData.costPerHour.toFixed(2)}</ThemedText>
                </View>
                
                <View style={[styles.infoCard, styles.totalCard]}>
                  <ThemedText style={styles.infoLabel}>Valor Total</ThemedText>
                  <ThemedText style={[styles.infoValue, styles.totalValue]}>
                    R${sensorData.totalCost.toFixed(4)}
                  </ThemedText>
                </View>
              </View>
            </View>

            {/* Área do Gráfico */}
            <View style={styles.chartContainer}>
              <ThemedText style={styles.sectionTitle}>Consumo em Tempo Real</ThemedText>
              <View style={styles.chartPlaceholder}>
                <View style={styles.chartGrid}>
                  {Array.from({ length: 5 }).map((_, i) => (
                    <View key={i} style={styles.gridLine} />
                  ))}
                </View>
                <ThemedText style={styles.chartText}>Gráfico de Consumo</ThemedText>
                <ThemedText style={styles.chartSubtext}>
                  Monitoramento em tempo real do consumo energético
                </ThemedText>
              </View>
            </View>

            {/* Botões de Ação */}
            <View style={styles.actionButtons}>
              <TouchableOpacity 
                style={styles.disconnectButton} 
                onPress={() => setIsConnected(false)}
              >
                <Text style={styles.disconnectButtonText}>Desconectar</Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.settingsButton}>
                <Text style={styles.settingsButtonText}>⚙️ Configurações</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </ScrollView>
    </ThemedView>
  );
}

const getStyles = (colorScheme: 'light' | 'dark' | null) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colorScheme === 'dark' ? '#1A1A1A' : '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 50,
    paddingBottom: 20,
    backgroundColor: colorScheme === 'dark' ? '#2D2D2D' : '#F1F1F1',
  },
  logo: {
    fontSize: 28,
    fontWeight: '700',
    color: '#B8DBD9',
  },
  menuButton: {
    padding: 10,
  },
  menuIcon: {
    fontSize: 24,
    color: colorScheme === 'dark' ? '#FFFFFF' : '#000000',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  disconnectedContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 50,
  },
  warningIcon: {
    fontSize: 48,
    marginBottom: 20,
  },
  warningText: {
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 40,
    paddingHorizontal: 20,
  },
  primaryButton: {
    backgroundColor: '#B8DBD9',
    paddingHorizontal: 40,
    paddingVertical: 15,
    borderRadius: 200,
    marginBottom: 20,
    minWidth: 200,
  },
  primaryButtonText: {
    color: '#000000',
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  secondaryButton: {
    backgroundColor: 'transparent',
    borderWidth: 2,
    borderColor: '#B8DBD9',
    paddingHorizontal: 40,
    paddingVertical: 15,
    borderRadius: 200,
    minWidth: 200,
  },
  secondaryButtonText: {
    color: '#B8DBD9',
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  connectedContainer: {
    paddingVertical: 20,
  },
  infoPanel: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 15,
    color: '#B8DBD9',
  },
  infoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  infoCard: {
    backgroundColor: colorScheme === 'dark' ? '#2D2D2D' : '#F1F1F1',
    padding: 15,
    borderRadius: 30,
    width: (width - 60) / 2,
    marginBottom: 15,
    alignItems: 'center',
  },
  totalCard: {
    width: width - 40,
    backgroundColor: '#B8DBD9',
  },
  infoLabel: {
    fontSize: 12,
    marginBottom: 5,
    opacity: 0.7,
  },
  infoValue: {
    fontSize: 18,
    fontWeight: '700',
  },
  totalValue: {
    color: '#000000',
    fontSize: 24,
  },
  chartContainer: {
    marginBottom: 30,
  },
  chartPlaceholder: {
    backgroundColor: colorScheme === 'dark' ? '#2D2D2D' : '#F1F1F1',
    height: 200,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  chartGrid: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'space-around',
  },
  gridLine: {
    height: 1,
    backgroundColor: colorScheme === 'dark' ? '#404040' : '#E0E0E0',
    marginHorizontal: 20,
  },
  chartText: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 5,
  },
  chartSubtext: {
    fontSize: 14,
    opacity: 0.7,
    textAlign: 'center',
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 30,
  },
  disconnectButton: {
    backgroundColor: '#FF6B6B',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 200,
    flex: 0.45,
  },
  disconnectButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  settingsButton: {
    backgroundColor: colorScheme === 'dark' ? '#2D2D2D' : '#F1F1F1',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 200,
    flex: 0.45,
  },
  settingsButtonText: {
    color: colorScheme === 'dark' ? '#FFFFFF' : '#000000',
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
});
