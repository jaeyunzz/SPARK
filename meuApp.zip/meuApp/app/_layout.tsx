import { DarkTheme, DefaultTheme, ThemeProvider } from '@react-navigation/native';
import { useFonts } from 'expo-font';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import 'react-native-reanimated';

import { useColorScheme } from '@/hooks/useColorScheme';

export default function RootLayout() {
  const colorScheme = useColorScheme();
  const [loaded] = useFonts({
    SpaceMono: require('../assets/fonts/SpaceMono-Regular.ttf'),
  });

  if (!loaded) {
    return null;
  }

  const sparkTheme = {
    ...DefaultTheme,
    colors: {
      ...DefaultTheme.colors,
      primary: '#B8DBD9',
      background: '#FFFFFF',
      card: '#F1F1F1',
      text: '#000000',
      border: '#B8DBD9',
      notification: '#B8DBD9',
    },
  };

  const sparkDarkTheme = {
    ...DarkTheme,
    colors: {
      ...DarkTheme.colors,
      primary: '#B8DBD9',
      background: '#1A1A1A',
      card: '#2D2D2D',
      text: '#FFFFFF',
      border: '#B8DBD9',
      notification: '#B8DBD9',
    },
  };

  return (
    <ThemeProvider value={colorScheme === 'dark' ? sparkDarkTheme : sparkTheme}>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="+not-found" />
      </Stack>
      <StatusBar style={colorScheme === 'dark' ? 'light' : 'dark'} />
    </ThemeProvider>
  );
}
