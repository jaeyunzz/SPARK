# 🚀 Como subir o projeto para o GitHub

## Comandos para executar após criar o repositório no GitHub:

```powershell
# 1. Adicionar o repositório remoto (substitua pela sua URL)
git remote add origin https://github.com/SEUUSUARIO/meuApp.git

# 2. Renomear a branch para main (padrão atual do GitHub)
git branch -M main

# 3. Subir o código para o GitHub
git push -u origin main
```

## Próximos commits:

Para futuras alterações no código:

```powershell
# Adicionar arquivos modificados
git add .

# Fazer commit com mensagem descritiva
git commit -m "Descrição das alterações"

# Subir para o GitHub
git push
```

## Verificar status:

```powershell
# Ver status dos arquivos
git status

# Ver histórico de commits
git log --oneline

# Ver repositórios remotos configurados
git remote -v
```
