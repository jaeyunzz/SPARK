const { getDefaultConfig } = require('expo/metro-config');

/** @type {import('expo/metro-config').MetroConfig} */
const config = getDefaultConfig(__dirname);

// Configurações para melhor compatibilidade
config.resolver.platforms = ['native', 'web', 'ios', 'android'];

// Configuração para resolver warnings de deprecated styles
config.transformer.minifierConfig = {
  keep_fnames: true,
  mangle: {
    keep_fnames: true,
  },
};

module.exports = config;