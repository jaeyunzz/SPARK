# 🚀 SPARK - Guia de Execução

## ⚠️ PROBLEMAS RESOLVIDOS:

### 1. Política de Execução do PowerShell
Se você receber erro de execução de scripts, execute este comando no PowerShell como ADMINISTRADOR:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### 2. Limpeza Completa do Projeto
Execute o arquivo `clean-project.bat` ou faça manualmente:

**No PowerShell:**
```powershell
# Pare todos os processos Node
taskkill /f /im node.exe

# Remova arquivos de cache
Remove-Item -Recurse -Force node_modules -ErrorAction SilentlyContinue
Remove-Item package-lock.json -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force .expo -ErrorAction SilentlyContinue
```

### 3. Reinstalação Limpa
```bash
npm cache clean --force
npm install --legacy-peer-deps
```

### 4. Execução do Projeto  
```bash
# Instale primeiro com flag de compatibilidade
npm install --legacy-peer-deps

# Depois execute o projeto
npx expo start -c

# Ou se ainda houver problemas com CLI global
npm install -g @expo/cli@latest
npx @expo/cli start -c
```

## 🔧 VERSÕES CORRIGIDAS:
- React: 19.0.0 (compatível com React Native 0.79.6)
- React Native: 0.79.6 (versão atual)
- @expo/cli: versão mais recente
- Configuração TypeScript otimizada
- Metro config melhorado
- .npmrc configurado para legacy-peer-deps

## 🌐 ACESSO:
- **Web:** http://localhost:8081
- **Mobile:** Use Expo Go e escaneie o QR code
- **Android Emulator:** Pressione 'a'

## ⚡ COMANDOS ÚTEIS:
- `npx expo start -c` - Inicia com cache limpo
- `npx expo start --web` - Força abertura web
- `npx expo start --android` - Força Android
- `r` - Recarregar app
- `m` - Abrir menu de desenvolvimento
- `j` - Abrir debugger
- `Ctrl+C` - Parar servidor

## 📱 FUNCIONALIDADES SPARK:
- ✅ Monitoramento de energia em tempo real
- ✅ Painel de consumo interativo
- ✅ Configurações personalizáveis
- ✅ Modo escuro/claro
- ✅ Interface responsiva
- ✅ Simulação de dados realística