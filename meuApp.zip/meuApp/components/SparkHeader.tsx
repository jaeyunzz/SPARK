import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useColorScheme } from '@/hooks/useColorScheme';

interface HeaderProps {
  title?: string;
  showMenu?: boolean;
  onMenuPress?: () => void;
}

export function SparkHeader({ title = 'SPARK', showMenu = true, onMenuPress }: HeaderProps) {
  const colorScheme = useColorScheme();
  const styles = getStyles(colorScheme ?? 'light');

  return (
    <View style={styles.header}>
      <Text style={styles.logo}>{title}</Text>
      {showMenu && (
        <TouchableOpacity style={styles.menuButton} onPress={onMenuPress}>
          <Text style={styles.menuIcon}>☰</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const getStyles = (colorScheme: 'light' | 'dark') => StyleSheet.create({
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 50,
    paddingBottom: 20,
    backgroundColor: colorScheme === 'dark' ? '#2D2D2D' : '#F1F1F1',
  },
  logo: {
    fontSize: 28,
    fontWeight: '700',
    color: '#B8DBD9',
  },
  menuButton: {
    padding: 10,
  },
  menuIcon: {
    fontSize: 24,
    color: colorScheme === 'dark' ? '#FFFFFF' : '#000000',
  },
});