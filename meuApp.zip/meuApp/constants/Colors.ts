/**
 * SPARK - Sistema de Monitoramento de Energia Elétrica
 * Paleta de cores personalizada baseada na identidade visual do projeto
 */

const sparkPrimary = '#B8DBD9';
const sparkWhite = '#FFFFFF';
const sparkLightGray = '#F1F1F1';
const sparkBlack = '#000000';
const sparkDarkBackground = '#1A1A1A';
const sparkDarkCard = '#2D2D2D';

export const Colors = {
  light: {
    text: sparkBlack,
    background: sparkWhite,
    tint: sparkPrimary,
    icon: '#687076',
    tabIconDefault: '#666666',
    tabIconSelected: sparkPrimary,
    card: sparkLightGray,
    border: sparkPrimary,
    primary: sparkPrimary,
  },
  dark: {
    text: sparkWhite,
    background: sparkDarkBackground,
    tint: sparkPrimary,
    icon: '#9BA1A6',
    tabIconDefault: '#888888',
    tabIconSelected: sparkPrimary,
    card: sparkDarkCard,
    border: sparkPrimary,
    primary: sparkPrimary,
  },
};

// Cores específicas do SPARK para uso direto
export const SparkColors = {
  primary: sparkPrimary,
  white: sparkWhite,
  lightGray: sparkLightGray,
  black: sparkBlack,
  darkBackground: sparkDarkBackground,
  darkCard: sparkDarkCard,
  danger: '#FF6B6B',
  warning: '#FFA500',
  success: '#4CAF50',
};
